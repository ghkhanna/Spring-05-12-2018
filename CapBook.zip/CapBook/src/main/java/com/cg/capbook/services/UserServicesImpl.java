package com.cg.capbook.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

@Component(value="userServices")
public class UserServicesImpl implements UserServices{
	@Autowired
	UserDAO userDao;
	@Override
	public User registerUser(User user) {
		return userDao.save(user);
	}
	@Override
	public User getUserDetails(int userId) throws UserDetailsNotFoundException {
		return userDao.findById(userId).orElseThrow(()->
		new UserDetailsNotFoundException("user details are not found"));		
	}
	@Override
	public User editUserDetails(User user) {
		return userDao.save(user);
	}
	@Override
	public boolean deleteUserAccount(int userId) throws UserDetailsNotFoundException {
		userDao.findById(userId).orElseThrow(()->
		new UserDetailsNotFoundException("user details are not found"));
		userDao.deleteById(userId);
		return true;
	}
	@Override
	public List<User> getAllUserDetails() {
		return userDao.findAll();
	}
	@Override
	public User loginUser(String emailId, String password) throws IncorrectPasswordException {
		User user = userDao.findByEmail(emailId);
		if(password.equals(user.getPassword()))
			return user;
		else
			throw new IncorrectPasswordException("Incorrect password");
	}
}